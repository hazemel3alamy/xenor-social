INSERT OR IGNORE INTO users(name,email,password_hash,role) VALUES('XENOR Admin','admin@xenor.app','d08f27d750cc6cbe9c6bcc590d656eaca206522fe0940a0792c02f46242bb8dd','admin');
