# XENOR Social Hub

Cloudflare Worker + D1 social platform package.

Included: accounts, sessions, profiles, posts, likes, comments, sharing, friends, follow/block, messages, notifications, stories, reels, market, academy, services/orders, reports and admin APIs, plus PWA assets.

D1 is required. R2 is optional for real image/video uploads.

See DEPLOY.txt for deployment and verification.
